timestamp
=========

a python library which simplifies the task of getting various timestamps
